/** Automatically generated file. DO NOT MODIFY */
package com.example.blackjack_play;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}