package com.example.blackjack_play;

import java.io.*;
import java.util.*;

class Player extends GamePlayer {
	public Player(String name) {
		super(name);
	}
}